CREATE TRIGGER update_with_id
  BEFORE UPDATE
  ON cn_notebook
  FOR EACH ROW
  BEGIN
    SET NEW.id = (SELECT max(id) FROM cn_notebook) + 1;
  END;


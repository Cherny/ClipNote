CREATE TRIGGER update_by_create
  BEFORE UPDATE
  ON cn_notebook
  FOR EACH ROW
  BEGIN
    SET NEW.id = (SELECT max(id) FROM cn_notebook) + 1;
    SET NEW.date_time = now();
  END;


CREATE TRIGGER no_repeat_submit
  BEFORE INSERT
  ON cn_notebook
  FOR EACH ROW
  BEGIN
  IF ( (SELECT count(*) FROM cn_notebook WHERE body = NEW.body) > 0)
    THEN
    SET NEW.body = NULL;
  END IF;
  SET NEW.date_time = now();
  SET NEW.id = (SELECT max(id) FROM cn_notebook) + 1;
END;

